Samples recorded from my real, original pleiads pcb with the epson 7910 melody chip
