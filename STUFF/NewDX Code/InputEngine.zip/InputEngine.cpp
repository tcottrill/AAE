#include "InputEngine.h"

LPDIRECTINPUT8 CInputEngine::m_lpDirectInput=NULL;

CInputEngine::CInputEngine()
{
	m_lpDIKeyboard = NULL;

	memset(&m_cPreviousKeyboardBuffer, 0, sizeof(m_cPreviousKeyboardBuffer));
	memset(&m_cKeyboardBuffer, 0, sizeof(m_cKeyboardBuffer));

	m_bKeyboardLost = false;
	m_bMouseLost = false;
	m_bSwapMouseButtons = false;
}

HRESULT CInputEngine::Create(HINSTANCE hinst,HWND hwnd)
{
	HRESULT hr = DirectInput8Create(hinst, DIRECTINPUT_VERSION, 
		IID_IDirectInput8, (void**)&m_lpDirectInput, NULL); 
	if FAILED(hr) 
	{ 
		return hr; 
	} 
	hr = CreateKeyboard(hwnd);
	if FAILED(hr) 
	{ 
		return hr; 
	} 
	hr = CreateMouse(hwnd);
	if FAILED(hr) 
	{ 
		return hr; 
	} 

	return DI_OK;
}

HRESULT CInputEngine::CreateKeyboard(HWND hwnd)
{
	HRESULT hr = m_lpDirectInput->CreateDevice(GUID_SysKeyboard, &m_lpDIKeyboard, NULL); 
	if FAILED(hr) { 
		return hr; 
	} 
	hr = m_lpDIKeyboard->SetDataFormat(&c_dfDIKeyboard); 
	if FAILED(hr) { 
		return hr; 
	} 
	hr = m_lpDIKeyboard->SetCooperativeLevel(hwnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE); 
	if FAILED(hr) { 
		return hr; 
	} 
	m_lpDIKeyboard->Acquire(); 
	return DI_OK;
}

HRESULT CInputEngine::CreateMouse(HWND hwnd)
{
	HRESULT hr = m_lpDirectInput->CreateDevice(GUID_SysMouse, &m_lpDIMouse, NULL); 
	if FAILED(hr) 
	{ 
		return hr; 
	} 
	hr = m_lpDIMouse->SetDataFormat(&c_dfDIMouse); 
	if FAILED(hr) 
	{ 
		return hr; 
	} 
	m_bExclusive = true;
	hr = m_lpDIMouse->SetCooperativeLevel(hwnd, DISCL_FOREGROUND | DISCL_EXCLUSIVE); 
	if FAILED(hr) 
	{ 
		return hr; 
	} 

	DIPROPDWORD dipdw;
	// the header
	dipdw.diph.dwSize       = sizeof(DIPROPDWORD);
	dipdw.diph.dwHeaderSize = sizeof(DIPROPHEADER);
	dipdw.diph.dwObj        = 0;
	dipdw.diph.dwHow        = DIPH_DEVICE;
	// the data
	dipdw.dwData            = MOUSE_BUFFER;

	hr = m_lpDIMouse->SetProperty(DIPROP_BUFFERSIZE, &dipdw.diph);
	if (FAILED(hr)) 
	{
		return FALSE;
	}

	GetWindowRect(hwnd, &m_WindowRect);
	RECT rect;
	GetClientRect(hwnd, &rect);
	POINT WindowClientOffset;
	WindowClientOffset.x = (m_WindowRect.right-rect.right)/2;
	WindowClientOffset.y = (m_WindowRect.bottom-rect.bottom)/2;
	POINT p;
	GetCursorPos(&p);
	m_lpDIMouse->Acquire(); 
	m_MouseState.x = p.x - m_WindowRect.left - WindowClientOffset.x;
	m_MouseState.y = p.y - m_WindowRect.top - WindowClientOffset.y;

	return DI_OK;
}

void CInputEngine::GetKeyboardState()
{
	memcpy(&m_cPreviousKeyboardBuffer, m_cKeyboardBuffer, sizeof(m_cPreviousKeyboardBuffer));
	HRESULT  hr; 
	if(m_bKeyboardLost)
	{
		if(m_lpDIKeyboard->Acquire() == DI_OK)
		{
			m_bKeyboardLost = false;
		}
	}
	hr = m_lpDIKeyboard->GetDeviceState(sizeof(m_cKeyboardBuffer),(LPVOID)&m_cKeyboardBuffer); 
	if FAILED(hr) 
	{ 
		// If it failed, the device has probably been lost. 
		// Check for (hr == DIERR_INPUTLOST) 
		// and attempt to reacquire it here. 
		if(hr == DIERR_INPUTLOST) 
		{
			m_bKeyboardLost = true;
		}
		return; 
	} 
}

CMouseState CInputEngine::GetMouseState(HWND hWnd)
{
	//	InvalidateCursorRect(hWnd);
	m_dwMouseBufferElements = MOUSE_BUFFER;   // number of items to be retrieved
	if(m_bMouseLost)
	{
		POINT p;
		GetCursorPos(&p);
		if(m_lpDIMouse->Acquire() == DI_OK)
		{
			m_bMouseLost = false;
			m_MouseState.x = p.x;
			m_MouseState.y = p.y;
		}
	}
	m_MouseState.dx = 0;
	m_MouseState.dy = 0;
	m_MouseState.Wheel = 0;
	bool bDone = false;
	HRESULT hr = m_lpDIMouse->GetDeviceData(sizeof(DIDEVICEOBJECTDATA), 
		m_pDIDOD, &m_dwMouseBufferElements, 0 );
	if (hr == DIERR_INPUTLOST) 
	{
		m_bMouseLost = true;
	}
	else if(hr == DIERR_NOTACQUIRED)
	{
		m_lpDIMouse->Acquire();
	}
	/* Unable to read data or no data available */
	if (FAILED(hr)) 
	{
		ROU_LOG("m_lpDIMouse->GetDeviceData failed!");
	}

	for (DWORD i=0;i<m_dwMouseBufferElements; i++) 
	{
		DIDEVICEOBJECTDATA od = m_pDIDOD[i];
		switch (od.dwOfs) 
		{
			// DIMOFS_BUTTON2: Middle button pressed or released 
		case DIMOFS_BUTTON2:
			if (od.dwData & 0x80)  // Middle button pressed, so
				// go into button-down mode
			{
				m_MouseState.ButtonDown[BUTTON2] = true;
			}
			else
			{
				m_MouseState.ButtonDown[BUTTON2] = false;
			}
			break;
			// DIMOFS_BUTTON1: Right button pressed or released 
		case DIMOFS_BUTTON1:
			// DIMOFS_BUTTON0: Left button pressed or released 
		case DIMOFS_BUTTON0:
			// Is the right button or a swapped left button down?
			if((m_bSwapMouseButtons && 
				DIMOFS_BUTTON1 == od.dwOfs) ||
				(!m_bSwapMouseButtons && 
				DIMOFS_BUTTON0 == od.dwOfs))
			{
				if (od.dwData & 0x80)  // Left button pressed, so
					// go into button-down mode
				{
					m_MouseState.ButtonDown[BUTTON1] = true;
				}
				else
				{
					m_MouseState.ButtonDown[BUTTON1] = false;
				}
			}
			// Is the left button or a swapped right button down?
			if((m_bSwapMouseButtons && 
				DIMOFS_BUTTON0 == od.dwOfs) ||
				(!m_bSwapMouseButtons && 
				DIMOFS_BUTTON1 == od.dwOfs))
			{
				if(od.dwData & 0x80)  // button release, so
					// check shortcut menu
				{  
					m_MouseState.ButtonDown[BUTTON3] = true;
				}
				else
				{
					m_MouseState.ButtonDown[BUTTON3] = false;
				}
			}
			break;        
			// Mouse horizontal motion
		case DIMOFS_X: 
			m_MouseState.x += od.dwData-1; 
			m_MouseState.dx = od.dwData; 
			break;
			// Mouse vertical motion
		case DIMOFS_Y: 
			m_MouseState.y += od.dwData-1; 
			m_MouseState.dy = od.dwData; 
			break; 
		case DIMOFS_Z:
			m_MouseState.Wheel = od.dwData; 
			break;
		}
	}
	/*
	RECT rect;
	GetClientRect(hWnd, &rect);
	if((m_MouseState.x < rect.left || m_MouseState.x > rect.right ||
		m_MouseState.y < rect.top || m_MouseState.y > rect.bottom)&& m_bExclusive)
	{
		GetWindowRect(hWnd, &m_WindowRect);
		POINT WindowClientOffset;
		WindowClientOffset.x = (m_WindowRect.right-rect.right)/2;
		WindowClientOffset.y = (m_WindowRect.bottom-rect.bottom)/2;
		m_lpDIMouse->Unacquire();
		m_lpDIMouse->SetCooperativeLevel(hWnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE); 
		m_bExclusive = false;
		m_lpDIMouse->Acquire(); 
		SetCursorPos(m_MouseState.x - m_WindowRect.left - WindowClientOffset.x, 
					 m_MouseState.y - m_WindowRect.top - WindowClientOffset.y);

	}
	else if(!m_bExclusive)
	{
		m_lpDIMouse->Unacquire();
		m_lpDIMouse->SetCooperativeLevel(hWnd, DISCL_FOREGROUND | DISCL_EXCLUSIVE); 
		m_bExclusive = true;
		m_lpDIMouse->Acquire(); 
	}*/
	return m_MouseState;
}

bool CInputEngine::KeyDown(int key)
{
	if(m_cKeyboardBuffer[key] & 0x80)
		return true;
	else
		return false;
}
bool CInputEngine::KeyUp(int key)
{
	if(!(m_cKeyboardBuffer[key] & 0x80) && (m_cPreviousKeyboardBuffer[key] & 0x80))
		return true;
	else
		return false;
}
void CInputEngine::Destroy()
{
	ROU_RELEASE(m_lpDirectInput);
	ROU_RELEASE(m_lpDIKeyboard);
	ROU_RELEASE(m_lpDIMouse);
}

CInputEngine::~CInputEngine()
{
}
