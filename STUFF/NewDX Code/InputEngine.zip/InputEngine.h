#ifndef CInputEngine_h_
#define CInputEngine_h_


//Standardausgabe
#include <stdio.h>
//string funktionen
#include <string.h>
#include <tchar.h>
#include <windows.h>

#define DIRECTINPUT_VERSION 0x0800
#define MOUSE_BUFFER 256
//Der Name des Logfile
#define ROU_LOGFILE "logfile.txt"

//Makro zum löschen des Logfile
#define ROU_LOG_CLEAR \
	{\
	_tremove( TEXT(ROU_LOGFILE) );\
	}
//Makro zum eintragen ins Logfile
#define ROU_LOG(string) \
	{\
	FILE* pFile;\
	_tfopen_s(&pFile,TEXT(ROU_LOGFILE),TEXT("a+"));\
	_ftprintf_s(pFile,TEXT("%s\n\n"), string);\
	fclose(pFile);\
	}

#define ROU_RELEASE(var) \
	if(var!=NULL)\
	{\
		var->Release();\
		var = NULL;\
	}

#include "dinput.h"
#include "dinputd.h"

enum E_MOUSEBUTTONS
{
	BUTTON1 = 0, //Normally Left MB
	BUTTON2,	 //Normally Middle MB
	BUTTON3,	 //Normally Right MB
	BUTTON4,	 
	BUTTON5,	 
	BUTTON6,	 
	NUM_MOUSEBUTTONS
};

class CMouseState
{
public:
	CMouseState::CMouseState()
	{
		Reset();
	}
	inline void Reset()
	{
		for(int i=0; i<NUM_MOUSEBUTTONS;i++)
		{
			ButtonDown[i] = false;
		}
		Wheel = 0;
		x = 0;
		y = 0;
		dx = 0;
		dy = 0;
	}
	bool ButtonDown[NUM_MOUSEBUTTONS];
	int  Wheel;
	int x;
	int y;
	int dx;
	int dy;
};

//Klasse für 3D Objekte
class CInputEngine
{
public:
	CInputEngine();
	virtual ~CInputEngine();

	//Zum Erstellen
	HRESULT Create(HINSTANCE hinst,HWND hwnd);

	//Zum Zerstören.
	void Destroy();

	void GetKeyboardState();
	bool KeyDown(int key);
	bool KeyUp(int key);

	CMouseState GetMouseState(HWND hWnd);
private:

	HRESULT CreateKeyboard(HWND hwnd);
	HRESULT CreateMouse(HWND hwnd);

	static LPDIRECTINPUT8 m_lpDirectInput;

	LPDIRECTINPUTDEVICE8 m_lpDIKeyboard;
	LPDIRECTINPUTDEVICE8 m_lpDIMouse;

	char m_cKeyboardBuffer[256];
	char m_cPreviousKeyboardBuffer[256];

	DIDEVICEOBJECTDATA m_pDIDOD[MOUSE_BUFFER];
	DWORD m_dwMouseBufferElements;

	bool m_bKeyboardLost;
	bool m_bMouseLost;

	bool m_bSwapMouseButtons;

	CMouseState m_MouseState;

	RECT m_WindowRect;
	bool m_bExclusive;
};

#endif
