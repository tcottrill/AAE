#include "SDKSound.h"
#include "windows.h"
#include "tchar.h"

bool g_bContinue = true;
//These are the classes needed for sound.///
CSound* g_pSound1;
CSound* g_pSound2;
CSoundManager g_SoundManager;
////////////////////////////////////////////
TCHAR* Output = TEXT("Press 1 to play Sound1. Press 2 to stop it\nPress 3 to play Sound2. Press 4 to stop it");
RECT Rect={10,10,300,50};
TCHAR* OutputS1 = TEXT("Playing Sound1");
RECT Rect1={10,50,300,70};
TCHAR* OutputS2 = TEXT("Playing Sound2");
RECT Rect2={10,70,300,90};
COLORREF colBackground = RGB(255, 255, 255);
COLORREF colText = RGB(0, 0, 0);
HBRUSH whiteBrush = CreateSolidBrush(colBackground);

//Besides the main function, there must be a message processing function
LRESULT WINAPI MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	HDC hdc = GetDC(hWnd);
	switch( msg )
	{
	case WM_KEYDOWN:
		switch (wParam)
		{
		case '1':
			if(!g_pSound1->IsSoundPlaying())
			{
				//Play sound1
				g_pSound1->Play(0,DSBPLAY_LOOPING,2000);
				DrawText(hdc, OutputS1, -1, &Rect1, DT_WORDBREAK);
			}
			break;
		case '2':
			//Stop sound1
			g_pSound1->Stop();
			FillRect(hdc, &Rect1, whiteBrush);
			break;
		case '3':
			if(!g_pSound2->IsSoundPlaying())
			{
				//Play sound2
				g_pSound2->Play(0,DSBPLAY_LOOPING,2000);
				DrawText(hdc, OutputS2, -1, &Rect2, DT_WORDBREAK);
			}
			break;
		case '4':
			//Stop sound2
			g_pSound2->Stop();
			FillRect(hdc, &Rect2, whiteBrush);
			break;
		}
		break;

	case WM_DESTROY:
		PostQuitMessage( 0 );
		g_bContinue = false;
		return 0;
	}
	return DefWindowProc( hWnd, msg, wParam, lParam );
}

//The entry point of a windows application is the WinMain function
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
	//Create a window class.
	WNDCLASSEX wc = { sizeof(WNDCLASSEX), CS_CLASSDC, MsgProc, 0L, 0L, 
		GetModuleHandle(NULL), NULL, NULL, CreateSolidBrush(colBackground), NULL,
		TEXT("DirectSound Window"), NULL };
	//Register the window class.
	RegisterClassEx( &wc );
	//Create the application's window.
	HWND hWnd = CreateWindow( TEXT("DirectSound Window"), TEXT("DirectX Wiki - DirectSound Tutorial 1"), 
		WS_OVERLAPPEDWINDOW, 100, 100, 400, 400,
		GetDesktopWindow(), NULL, wc.hInstance, NULL );
	ShowWindow(hWnd,SW_SHOW);

	//This is all you have to do!/////////////////////////////////////
	if(FAILED(g_SoundManager.Initialize(hWnd, DSSCL_PRIORITY)))
		return 0;
	if(FAILED(g_SoundManager.SetPrimaryBufferFormat( 2, 22050, 16 )))
		return 0;
	if(FAILED(g_SoundManager.Create( &g_pSound1, TEXT("Sound1.wav") )))
		return 0;
	if(FAILED(g_SoundManager.Create( &g_pSound2, TEXT("Sound2.wav") )))
		return 0;
	////////////////////////////////////////////////////////////////////

	HFONT hf;
	hf = CreateFont(12, 0, 0, 0, 0, TRUE, 0, 0, 0, 0, 0, 0, 0, TEXT("Arial"));
	MSG msg; 
	HDC hdc = GetDC(hWnd);
	SetBkColor(hdc, colBackground);
	SetTextColor(hdc, colText);
	DrawText(hdc, Output, -1, &Rect, DT_WORDBREAK);
	while( g_bContinue )
	{
		// A window has to handle its messages.
		TranslateMessage( &msg );
		DispatchMessage( &msg );
		PeekMessage(&msg, 0, 0, 0, PM_REMOVE);
	}

	return 0;
}