+---------------------------------------------------------------------------.
Title           : Tempest Level and Extra Bonus Men Hacks                   :
Version         : 1.2                                                       :
Date            : 16-September-2004                                         :
Author          : Josh McCormick                                            :
+---------------------------------------------------------------------------.
                                                                            :
                                                                            :
+----------.                                                                :
 Background \                                                               :
+------------`--------------------------------------------------------------.
                                                                            :
                                                                            :
These modified Tempest ROM files will allow you to (a) select               :
any level you want (up to 81, the green level), any time you                :
play, regardless of score; or (b) increase the limit of bonus               :
lives from 6 to 255 (although at most, only 6 lives will be                 :
displayed at the top of the screen). You can use one hack or                :
both.                                                                       :
                                                                            :
The CRC checksums for each modified ROM are fixed so there will             :
be no errors reported in the self-test. As it turns out, and                :
what really makes sense, is that checksums are performed                    :
(at $DA0A) on each individual ROM, so checksum corrections need             :
only be made on the ROM that is modified.                                   :
                                                                            :
This information is partly based on my own work, upon the more              :
recent disassembly and commentary by der Mouse, the work of Mark            :
Spaeth and the MAME team such that I could test the modified code.          :
                                                                            :
                                                                            :
+--------------------------.                                                :
 Atari Checksum Calculation \                                               :
+----------------------------`----------------------------------------------.
                                                                            :
Calculating the checksum is interesting, yet simple. First, Tempest is      :
laid out in ROMs that each cover a $0800 region. For simplicity's sake,     :
let's number the main program ROMs $0-$B.                                   :
                                                                            :
What it does is XOR all of the bytes in a ROM together. It then XORs        :
in the region number (that $0-$B number) to the final figure. It does       :
this for all ROM regions. If it the result is zero, the checksum for        :
that ROM passes. If it is non-zero, on the first screen of the Tempest      :
operator mode, it displays the ROM region number, and the resulting         :
checksum value.                                                             :
                                                                            :
To correct the checksum, you must find a byte in the ROM that is not        :
used. Then, XOR that byte with the checksum result above. That'll           :
return the checksum to zero for that chip, which allows it to pass          :
self-test.                                                                  :
                                                                            :
For example:                                                                :
                                                                            :
   1] Locate a byte in the ROM which is not used. Lets say that             :
      offset $1AB doesn't appear to be used, and holds a value of $67.      :
                                                                            :
   2] Determine what the current checksum error is for that ROM.            :
      This involves going into the operator mode. It'll list the ROM        :
      number and the checksum mismatch for that ROM. Let's say that         :
      the bad checksum value is $FE.                                        :
                                                                            :
   3] To correct the checksum for the ROM, you'll need to XOR the           :
      existing byte with the checksum error. Worse case, you can            :
      use Windows Calculator to do this. Go into Scientific mode.           :
      Enable the Hex button. Type "67", hit the Xor button, type in         :
      "FE". Hit equals. The checksum correction is $99.                     :
                                                                            :
   4] Go into offset $1AB of the ROM file. Check $67 to $99. You have       :
      now corrected the CRC. The ROM check in operator mode should no       :
      longer report a problem with that ROM. Lather, rinse, and repeat      :
      for additional ROMs.                                                  :
                                                                            :
   NOTE: I did notice an additional checksum test for just the              :
         copyright notice. You're on your own if you want to modify it.     :
         There isn't any real reason why you should.                        :
                                                                            :
                                                                            :
It is clear that der Mouse discovered this on his own and clearly           :
documented it in his code at location $DA0A. I'm assuming I'm the first     :
to understand the importance of his find, put that discovery into a         :
practical application.                                                      :
                                                                            :
For reference, here are der Mouse's code comments:                          :
                                                                            :
; Okay, all RAM passed selftest.                                            :
; Checksum ROM.  For each $0800 region, XOR all its bytes together and      :
; XOR in its region number (0 for the first, 1 for the second, etc), then   :
; store the result in the space at $7d.  Ranges for each of the 12 bytes:   :
; $7d - $3000-$37ff                                                         :
; $7e - $3800-$38ff                                                         :
; $7f - $9000-$97ff                                                         :
; $80 - $9800-$9fff                                                         :
; $81 - $a000-$a7ff                                                         :
; $82 - $a800-$afff                                                         :
; $83 - $b000-$b7ff                                                         :
; $84 - $b800-$bfff                                                         :
; $85 - $c000-$c7ff                                                         :
; $86 - $c800-$cfff                                                         :
; $87 - $d000-$d7ff                                                         :
; $88 - $d800-$dfff                                                         :
; All checksums computed and stored in $7d-$88.                             :
; Show any nonzero checksums (stored in the 12 bytes from $7d to $88)       :
                                                                            :
                                                                            :
+---------.                                                                 :
 The Hack! \                                                                :
+-----------`---------------------------------------------------------------.
                                                                            :
If you want to manually change the code, here are the details:              :
                                                                            :
                                                                            :
   For the .113 ROM, you modify offset (hex) $CD-CE from "90FA"             :
   to "EAEA". For checksum, I modified the second byte from BB to D1.       :
                                                                            :
   For the .120 ROM, I modified offsex (hex) $2E1 from 06 to FF.            :
   For checksum, I modified hex offset $5E5 from 50 to A9.                  :
                                                                            :
                                                                            :
NOTE: These hacks have been tested to work with Tempest rev1, rev2,         :
      or rev3 ROM sets. I have not tested these hacks on the                :
      prototype sets.                                                       :
                                                                            :
                                                                            :
+-----.                                                                     :
 Files \                                                                    :
+-------`-------------------------------------------------------------------.
                                                                            :
                                                                            :
136002.113  [open level hack]                                               :
136002.120  [extra bonus men hack]                                          :
                                                                            :
                                                                            :
+---------------------------------------------------------------------------: